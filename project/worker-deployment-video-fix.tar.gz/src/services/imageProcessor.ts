import sharp from 'sharp';
import ffmpeg from 'fluent-ffmpeg';
import { logger } from '../logger.js';
import { promises as fs } from 'fs';
import { tmpdir } from 'os';
import { join } from 'path';

export interface ImageMetadata {
  width: number;
  height: number;
}

export interface ImageVariant {
  buffer: Buffer;
  width: number;
  height: number;
}

export interface ImageVariants {
  thumb: ImageVariant;
  display: ImageVariant;
}

export class ImageProcessor {
  async processImage(sourceBuffer: Buffer): Promise<ImageVariants> {
    logger.debug('Processing image', { size: sourceBuffer.length });

    try {
      const image = sharp(sourceBuffer);
      const metadata = await image.metadata();

      logger.debug('Image metadata', {
        format: metadata.format,
        width: metadata.width,
        height: metadata.height,
      });

      const [thumb, display] = await Promise.all([
        this.createThumbnail(sourceBuffer),
        this.createDisplay(sourceBuffer),
      ]);

      logger.info('Image processed successfully', {
        thumbSize: thumb.buffer.length,
        displaySize: display.buffer.length,
      });

      return { thumb, display };
    } catch (error) {
      logger.error('Image processing failed', error as Error);
      throw error;
    }
  }

  private async createThumbnail(buffer: Buffer): Promise<ImageVariant> {
    const image = sharp(buffer)
      .rotate()
      .resize(400, 400, {
        fit: 'inside',
        withoutEnlargement: true,
      })
      .webp({ quality: 80 });

    const processedBuffer = await image.toBuffer();
    const metadata = await sharp(processedBuffer).metadata();

    return {
      buffer: processedBuffer,
      width: metadata.width || 0,
      height: metadata.height || 0,
    };
  }

  private async createDisplay(buffer: Buffer): Promise<ImageVariant> {
    const image = sharp(buffer)
      .rotate()
      .resize(1600, 1600, {
        fit: 'inside',
        withoutEnlargement: true,
      })
      .webp({ quality: 80 });

    const processedBuffer = await image.toBuffer();
    const metadata = await sharp(processedBuffer).metadata();

    return {
      buffer: processedBuffer,
      width: metadata.width || 0,
      height: metadata.height || 0,
    };
  }

  async processVideoThumbnail(videoBuffer: Buffer): Promise<ImageVariants> {
    logger.debug('Generating video thumbnail', { size: videoBuffer.length });

    const tempDir = tmpdir();
    const videoPath = join(tempDir, `video-${Date.now()}.mp4`);
    const thumbnailPath = join(tempDir, `thumb-${Date.now()}.png`);

    try {
      await fs.writeFile(videoPath, videoBuffer);

      await new Promise<void>((resolve, reject) => {
        ffmpeg(videoPath)
          .screenshots({
            timestamps: ['00:00:01'],
            filename: thumbnailPath.split('/').pop()!,
            folder: tempDir,
            size: '1600x?'
          })
          .on('end', () => resolve())
          .on('error', (err) => reject(err));
      });

      const thumbnailBuffer = await fs.readFile(thumbnailPath);

      const [thumb, display] = await Promise.all([
        this.createThumbnail(thumbnailBuffer),
        this.createDisplay(thumbnailBuffer),
      ]);

      await fs.unlink(videoPath).catch(() => {});
      await fs.unlink(thumbnailPath).catch(() => {});

      logger.info('Video thumbnail generated successfully', {
        thumbSize: thumb.buffer.length,
        displaySize: display.buffer.length,
      });

      return { thumb, display };
    } catch (error) {
      await fs.unlink(videoPath).catch(() => {});
      await fs.unlink(thumbnailPath).catch(() => {});
      logger.error('Video thumbnail generation failed', error as Error);
      throw error;
    }
  }

  isImage(mimeType: string): boolean {
    return mimeType.startsWith('image/');
  }

  isVideo(mimeType: string): boolean {
    return mimeType.startsWith('video/');
  }
}
